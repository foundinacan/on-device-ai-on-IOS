# LocalAI (iOS)

SwiftUI app that browses Hugging Face for GGUF models, downloads them, and runs them on-device with llama.cpp (Metal). Shows live prompt and generation tokens/sec plus token counts, and detects JIT at runtime.

## Build the IPA (easiest: GitHub Actions)
1. Push this folder to a GitHub repo.
2. Go to **Actions → Build unsigned IPA → Run workflow**. You can pin a llama.cpp tag such as `b6000`. If you leave it blank, it uses the latest release.
3. Download the `LocalAI-ipa` artifact and unzip it to get `LocalAI.ipa`. The IPA is unsigned.

## Build locally (Mac + Xcode 15+)
```bash
brew install xcodegen
./scripts/fetch-llama.sh       # downloads llama.xcframework into Frameworks/
xcodegen generate
open LocalAI.xcodeproj          # set your Team, then run on a device
```

## Sideload
- **SideStore / AltStore:** open the `.ipa` in the app, or use **+**. It gets signed with your Apple ID (free accounts get 7 days and 3 apps).
- **Entitlements:** `LocalAI.entitlements` lists `get-task-allow` (required so a debugger can attach and turn on JIT), `com.apple.security.cs.allow-jit`, and `dynamic-codesigning`. With free or developer signing, only `get-task-allow` survives. The other two are ignored or stripped unless you use TrollStore or similar. This is fine because the app falls back to normal mode.

## Enable JIT
iOS only allows JIT when a debugger is attached (`CS_DEBUGGED`).
- **StikDebug** (iOS 17.4+): set up the pairing file and VPN, open StikDebug, choose **Connect by App → LocalAI**.
- **SideStore:** long-press LocalAI in My Apps and choose **Enable JIT** (iOS versions older than 17 need the built-in support. Newer versions use StikDebug).
- In the app, go to **Settings → JIT** to see `CS_DEBUGGED` and the MAP_JIT test result.

When JIT is on, the engine uses more CPU threads and bigger prompt batches. llama.cpp is compiled ahead of time and runs on Metal, so JIT is mostly a "performance mode" plus a debugger-relaxed memory policy. Expect modest gains, not a huge jump.

## Use
1. **Hub** tab: search (e.g. `qwen2.5 0.5b`), open a repo, and tap ⬇︎ on a `.gguf` file. A Q4_K_M quant of a 0.5B–3B model works well on phones.
2. **Models** tab: tap a model to load it.
3. **Chat** tab: the bar at the top shows prompt tok/s, generation tok/s, input/output/total tokens, and JIT status.
4. **Settings**: optional HF token (stored in the Keychain), max tokens, and context size.

## Notes
- The code targets the current llama.cpp C API (`llama_model_load_from_file`, `llama_init_from_model`, `llama_memory_clear`, vocab-based tokenize). If an old or new tag breaks the build, pin `llama_tag` to a recent release.
- Each turn re-processes the whole templated chat, which keeps the code simple and robust.
