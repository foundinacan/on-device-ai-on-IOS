#!/usr/bin/env bash
# Downloads the prebuilt llama.xcframework from ggml-org/llama.cpp releases.
set -euo pipefail
cd "$(dirname "$0")/.."
TAG="${LLAMA_TAG:-$(curl -s https://api.github.com/repos/ggml-org/llama.cpp/releases/latest | python3 -c 'import sys,json;print(json.load(sys.stdin)["tag_name"])')}"
echo "llama.cpp tag: $TAG"
curl -L -o /tmp/llama.zip "https://github.com/ggml-org/llama.cpp/releases/download/$TAG/llama-$TAG-xcframework.zip"
rm -rf Frameworks/llama.xcframework /tmp/llamax && mkdir -p /tmp/llamax Frameworks
unzip -q /tmp/llama.zip -d /tmp/llamax
mv "$(find /tmp/llamax -name 'llama.xcframework' -type d | head -1)" Frameworks/
echo "OK -> Frameworks/llama.xcframework"
