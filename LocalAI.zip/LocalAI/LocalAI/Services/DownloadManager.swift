import Foundation

@MainActor
final class DownloadManager: NSObject, ObservableObject {
    @Published var progress: [String: Double] = [:]   // key = local filename
    @Published var localModels: [URL] = []
    @Published var lastError: String?
    private var tasks: [Int: String] = [:]
    private lazy var session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)

    static var modelsDir: URL {
        let d = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("models")
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    override init() { super.init(); refresh() }

    func refresh() {
        localModels = ((try? FileManager.default.contentsOfDirectory(at: Self.modelsDir, includingPropertiesForKeys: [.fileSizeKey])) ?? [])
            .filter { $0.pathExtension.lowercased() == "gguf" }.sorted { $0.lastPathComponent < $1.lastPathComponent }
    }

    func download(repo: String, file: String) {
        let name = repo.replacingOccurrences(of: "/", with: "__") + "__" + (file as NSString).lastPathComponent
        let task = session.downloadTask(with: HFClient.request(HFClient.downloadURL(repo: repo, file: file)))
        tasks[task.taskIdentifier] = name
        progress[name] = 0
        task.resume()
    }

    func delete(_ url: URL) { try? FileManager.default.removeItem(at: url); refresh() }
}

extension DownloadManager: URLSessionDownloadDelegate {
    nonisolated func urlSession(_ s: URLSession, downloadTask: URLSessionDownloadTask, didWriteData _: Int64,
                                totalBytesWritten w: Int64, totalBytesExpectedToWrite t: Int64) {
        let id = downloadTask.taskIdentifier
        Task { @MainActor in if let n = self.tasks[id], t > 0 { self.progress[n] = Double(w) / Double(t) } }
    }
    nonisolated func urlSession(_ s: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        let id = downloadTask.taskIdentifier
        // Must move synchronously before this method returns.
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try? FileManager.default.moveItem(at: location, to: tmp)
        Task { @MainActor in
            guard let n = self.tasks[id] else { return }
            let dest = Self.modelsDir.appendingPathComponent(n)
            try? FileManager.default.removeItem(at: dest)
            do { try FileManager.default.moveItem(at: tmp, to: dest) } catch { self.lastError = error.localizedDescription }
            self.progress[n] = nil; self.tasks[id] = nil; self.refresh()
        }
    }
    nonisolated func urlSession(_ s: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error else { return }
        let id = task.taskIdentifier
        Task { @MainActor in
            if let n = self.tasks[id] { self.progress[n] = nil }
            self.tasks[id] = nil; self.lastError = error.localizedDescription
        }
    }
}
