import Foundation

struct HFModel: Codable, Identifiable, Hashable {
    let id: String
    let downloads: Int?
    let likes: Int?
}

struct HFFile: Identifiable, Hashable {
    let path: String
    let size: Int64?
    var id: String { path }
}

enum HFClient {
    static let base = URL(string: "https://huggingface.co")!

    static func request(_ url: URL) -> URLRequest {
        var r = URLRequest(url: url)
        if let t = Keychain.hfToken, !t.isEmpty { r.setValue("Bearer \(t)", forHTTPHeaderField: "Authorization") }
        return r
    }

    static func search(_ query: String) async throws -> [HFModel] {
        var c = URLComponents(string: "https://huggingface.co/api/models")!
        c.queryItems = [.init(name: "search", value: query), .init(name: "filter", value: "gguf"),
                        .init(name: "sort", value: "downloads"), .init(name: "direction", value: "-1"),
                        .init(name: "limit", value: "50")]
        let (data, _) = try await URLSession.shared.data(for: request(c.url!))
        return try JSONDecoder().decode([HFModel].self, from: data)
    }

    private struct TreeEntry: Codable { let type: String; let path: String; let size: Int64?
        struct LFS: Codable { let size: Int64? }; let lfs: LFS? }

    static func ggufFiles(repo: String) async throws -> [HFFile] {
        let url = URL(string: "https://huggingface.co/api/models/\(repo)/tree/main?recursive=true")!
        let (data, _) = try await URLSession.shared.data(for: request(url))
        let entries = try JSONDecoder().decode([TreeEntry].self, from: data)
        return entries.filter { $0.type == "file" && $0.path.lowercased().hasSuffix(".gguf") }
            .map { HFFile(path: $0.path, size: $0.lfs?.size ?? $0.size) }
    }

    static func downloadURL(repo: String, file: String) -> URL {
        URL(string: "https://huggingface.co/\(repo)/resolve/main/\(file)?download=true")!
    }
}
