import SwiftUI

struct LocalModelsView: View {
    @EnvironmentObject var dl: DownloadManager
    @EnvironmentObject var engine: LlamaEngine

    var body: some View {
        NavigationStack {
            List {
                if let e = dl.lastError { Text(e).foregroundColor(.red) }
                if dl.localModels.isEmpty { Text("No models yet. Download a .gguf from the Hub tab.").foregroundColor(.secondary) }
                ForEach(dl.localModels, id: \.self) { url in
                    Button { Task { await engine.load(url) } } label: {
                        HStack {
                            Text(url.lastPathComponent).lineLimit(2)
                            Spacer()
                            if engine.loadedName == url.lastPathComponent { Image(systemName: "checkmark.circle.fill").foregroundColor(.green) }
                        }
                    }
                }
                .onDelete { idx in idx.map { dl.localModels[$0] }.forEach(dl.delete) }
            }
            .overlay { if engine.isLoading { ProgressView("Loading model…") } }
            .navigationTitle("Local models")
            .refreshable { dl.refresh() }
            .onAppear { dl.refresh() }
        }
    }
}
