import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var jit: JITStatus
    @EnvironmentObject var engine: LlamaEngine
    @State private var token = Keychain.hfToken ?? ""
    @State private var saved = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Hugging Face token (optional, for gated/private repos)") {
                    SecureField("hf_…", text: $token)
                    Button(saved ? "Saved to Keychain" : "Save") { Keychain.hfToken = token; saved = true }
                }
                Section("Generation") {
                    Stepper("Max tokens: \(engine.maxTokens)", value: $engine.maxTokens, in: 64...4096, step: 64)
                    Stepper("Context: \(engine.contextSize)", value: $engine.contextSize, in: 512...32768, step: 512)
                    Text("Context change applies on next model load.").font(.caption).foregroundColor(.secondary)
                }
                Section("JIT") {
                    Text(jit.summary).foregroundColor(jit.available ? .green : .orange)
                    Text("CS_DEBUGGED: \(jit.debugged ? "yes" : "no")")
                    Text("MAP_JIT test: \(jit.mapJIT ? "pass" : "fail")")
                    Button("Re-check") { jit.refresh() }
                    Text("Enable JIT by launching the app with StikDebug or SideStore → long-press app → Enable JIT. When enabled, the engine uses more threads and larger batches.")
                        .font(.caption).foregroundColor(.secondary)
                }
            }
            .navigationTitle("Settings")
        }
    }
}
