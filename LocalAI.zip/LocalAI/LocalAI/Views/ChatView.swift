import SwiftUI

struct ChatView: View {
    @EnvironmentObject var engine: LlamaEngine
    @EnvironmentObject var jit: JITStatus
    @State private var input = ""

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                StatsBar(stats: engine.stats, jit: jit.summary, generating: engine.isGenerating)
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 10) {
                            ForEach(engine.messages) { m in
                                Text(m.text.isEmpty && m.role == "assistant" ? "…" : m.text)
                                    .textSelection(.enabled)
                                    .padding(10)
                                    .background(m.role == "user" ? Color.blue.opacity(0.15) : Color.gray.opacity(0.15))
                                    .cornerRadius(10)
                                    .frame(maxWidth: .infinity, alignment: m.role == "user" ? .trailing : .leading)
                                    .id(m.id)
                            }
                        }.padding()
                    }
                    .onChange(of: engine.messages.last?.text) { _ in
                        if let id = engine.messages.last?.id { proxy.scrollTo(id, anchor: .bottom) }
                    }
                }
                if let e = engine.error { Text(e).foregroundColor(.red).font(.caption) }
                HStack {
                    TextField(engine.loadedName == nil ? "Load a model first" : "Message", text: $input, axis: .vertical)
                        .textFieldStyle(.roundedBorder).lineLimit(1...5)
                    if engine.isGenerating {
                        Button { engine.stop() } label: { Image(systemName: "stop.circle.fill").font(.title2) }
                    } else {
                        Button {
                            let t = input.trimmingCharacters(in: .whitespacesAndNewlines); input = ""
                            if !t.isEmpty { Task { await engine.send(t) } }
                        } label: { Image(systemName: "arrow.up.circle.fill").font(.title2) }
                        .disabled(engine.loadedName == nil)
                    }
                }.padding()
            }
            .navigationTitle(engine.loadedName ?? "Chat")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Clear") { engine.clear() } }
        }
    }
}

struct StatsBar: View {
    let stats: GenStats; let jit: String; let generating: Bool
    var body: some View {
        VStack(spacing: 2) {
            HStack {
                Label(String(format: "Prompt %.1f tok/s", stats.promptTPS), systemImage: "text.alignleft")
                Spacer()
                Label(String(format: "Gen %.1f tok/s", stats.genTPS), systemImage: "bolt.fill")
            }
            HStack {
                Text("Tokens: \(stats.promptTokens) in / \(stats.genTokens) out / \(stats.total) total")
                Spacer()
                Text(jit).foregroundColor(jit.contains("enabled") ? .green : .orange)
            }
        }
        .font(.caption.monospacedDigit())
        .padding(.horizontal).padding(.vertical, 6)
        .background(.ultraThinMaterial)
    }
}
