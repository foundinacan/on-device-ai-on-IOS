import SwiftUI

struct ModelBrowserView: View {
    @State private var query = "qwen gguf"
    @State private var results: [HFModel] = []
    @State private var loading = false
    @State private var error: String?

    var body: some View {
        NavigationStack {
            List {
                if let error { Text(error).foregroundColor(.red) }
                ForEach(results) { m in
                    NavigationLink(value: m) {
                        VStack(alignment: .leading) {
                            Text(m.id).font(.headline)
                            Text("⬇︎ \(m.downloads ?? 0)  ♥ \(m.likes ?? 0)").font(.caption).foregroundColor(.secondary)
                        }
                    }
                }
            }
            .overlay { if loading { ProgressView() } }
            .searchable(text: $query)
            .onSubmit(of: .search) { Task { await run() } }
            .navigationTitle("Hugging Face")
            .navigationDestination(for: HFModel.self) { RepoFilesView(repo: $0.id) }
            .task { if results.isEmpty { await run() } }
        }
    }

    func run() async {
        loading = true; error = nil
        do { results = try await HFClient.search(query) } catch { self.error = error.localizedDescription }
        loading = false
    }
}

struct RepoFilesView: View {
    let repo: String
    @EnvironmentObject var dl: DownloadManager
    @State private var files: [HFFile] = []
    @State private var error: String?

    var body: some View {
        List {
            if let error { Text(error).foregroundColor(.red) }
            ForEach(files) { f in
                let key = repo.replacingOccurrences(of: "/", with: "__") + "__" + (f.path as NSString).lastPathComponent
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        VStack(alignment: .leading) {
                            Text(f.path).font(.subheadline)
                            if let s = f.size { Text(ByteCountFormatter.string(fromByteCount: s, countStyle: .file)).font(.caption).foregroundColor(.secondary) }
                        }
                        Spacer()
                        Button { dl.download(repo: repo, file: f.path) } label: { Image(systemName: "arrow.down.circle") }
                            .disabled(dl.progress[key] != nil)
                    }
                    if let p = dl.progress[key] { ProgressView(value: p); Text("\(Int(p * 100))%").font(.caption2) }
                }
            }
        }
        .navigationTitle(repo.split(separator: "/").last.map(String.init) ?? repo)
        .task {
            do { files = try await HFClient.ggufFiles(repo: repo) } catch { self.error = error.localizedDescription }
        }
    }
}
