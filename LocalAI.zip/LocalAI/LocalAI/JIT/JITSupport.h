#pragma once
#include <stdbool.h>
/// True if the process has CS_DEBUGGED set (debugger attached / JIT enabled via StikDebug/SideStore).
bool lai_cs_debugged(void);
/// True if an RWX/MAP_JIT page can be mapped and executed-toggled.
bool lai_map_jit_works(void);
