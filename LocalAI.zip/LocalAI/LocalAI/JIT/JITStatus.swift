import Foundation

/// Runtime JIT detection. iOS only allows JIT when the app is launched with a
/// debugger attached (CS_DEBUGGED), e.g. via StikDebug or SideStore "Enable JIT".
final class JITStatus: ObservableObject {
    static let shared = JITStatus()
    @Published private(set) var debugged = false
    @Published private(set) var mapJIT = false
    var available: Bool { debugged || mapJIT }

    func refresh() {
        debugged = lai_cs_debugged()
        mapJIT = lai_map_jit_works()
    }

    var summary: String {
        available ? "JIT: enabled" + (debugged ? " (debugger attached)" : " (MAP_JIT)") : "JIT: off (normal mode)"
    }
}
