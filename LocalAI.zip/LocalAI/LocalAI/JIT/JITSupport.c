#include "JITSupport.h"
#include <sys/mman.h>
#include <unistd.h>
#include <stdint.h>
#define CS_OPS_STATUS 0
#define CS_DEBUGGED 0x10000000
extern int csops(pid_t pid, unsigned int ops, void *useraddr, size_t usersize);

bool lai_cs_debugged(void) {
    uint32_t flags = 0;
    if (csops(getpid(), CS_OPS_STATUS, &flags, sizeof(flags)) != 0) return false;
    return (flags & CS_DEBUGGED) != 0;
}

bool lai_map_jit_works(void) {
    size_t sz = (size_t)getpagesize();
#ifndef MAP_JIT
#define MAP_JIT 0x800
#endif
    void *p = mmap(NULL, sz, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANON | MAP_JIT, -1, 0);
    if (p == MAP_FAILED) {
        // Fallback: try RW then flip to RX (works when CS_DEBUGGED).
        p = mmap(NULL, sz, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
        if (p == MAP_FAILED) return false;
        bool ok = mprotect(p, sz, PROT_READ | PROT_EXEC) == 0;
        munmap(p, sz);
        return ok;
    }
    munmap(p, sz);
    return true;
}
