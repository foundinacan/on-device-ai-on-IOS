import Foundation
import llama

struct GenStats {
    var promptTokens = 0, genTokens = 0
    var promptTPS = 0.0, genTPS = 0.0
    var total: Int { promptTokens + genTokens }
}

struct ChatMessage: Identifiable { let id = UUID(); var role: String; var text: String }

/// Thin wrapper over the llama.cpp C API (llama.xcframework).
actor LlamaContext {
    private let model: OpaquePointer
    private let ctx: OpaquePointer
    private let vocab: OpaquePointer
    private var sampler: UnsafeMutablePointer<llama_sampler>
    private var nPast: Int32 = 0
    private var cancelled = false
    let nCtx: Int32

    init(path: String, nCtx: Int32, gpuLayers: Int32, threads: Int32) throws {
        llama_backend_init()
        var mp = llama_model_default_params()
        mp.n_gpu_layers = gpuLayers
        guard let m = llama_model_load_from_file(path, mp) else { throw NSError(domain: "llama", code: 1, userInfo: [NSLocalizedDescriptionKey: "Failed to load model"]) }
        var cp = llama_context_default_params()
        cp.n_ctx = UInt32(nCtx); cp.n_batch = 512
        cp.n_threads = threads; cp.n_threads_batch = threads
        guard let c = llama_init_from_model(m, cp) else { llama_model_free(m); throw NSError(domain: "llama", code: 2, userInfo: [NSLocalizedDescriptionKey: "Failed to create context"]) }
        model = m; ctx = c; vocab = llama_model_get_vocab(m); self.nCtx = nCtx
        sampler = llama_sampler_chain_init(llama_sampler_chain_default_params())
        llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40))
        llama_sampler_chain_add(sampler, llama_sampler_init_top_p(0.95, 1))
        llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.7))
        llama_sampler_chain_add(sampler, llama_sampler_init_dist(UInt32.random(in: 0...UInt32.max)))
    }

    deinit { llama_sampler_free(sampler); llama_free(ctx); llama_model_free(model) }

    func cancel() { cancelled = true }

    func reset() { llama_memory_clear(llama_get_memory(ctx), true); nPast = 0 }

    /// Applies the model's built-in chat template.
    func formatPrompt(_ msgs: [ChatMessage]) -> String {
        let tmpl = llama_model_chat_template(model, nil)
        var cstrs = msgs.map { (strdup($0.role)!, strdup($0.text)!) }
        defer { cstrs.forEach { free($0.0); free($0.1) } }
        var chat = cstrs.map { llama_chat_message(role: $0.0, content: $0.1) }
        var buf = [CChar](repeating: 0, count: 16384)
        var n = llama_chat_apply_template(tmpl, &chat, chat.count, true, &buf, Int32(buf.count))
        if n > buf.count { buf = [CChar](repeating: 0, count: Int(n) + 1); n = llama_chat_apply_template(tmpl, &chat, chat.count, true, &buf, Int32(buf.count)) }
        if n < 0 { return msgs.map { "\($0.role): \($0.text)" }.joined(separator: "\n") + "\nassistant:" }
        return String(decoding: buf.prefix(Int(n)).map { UInt8(bitPattern: $0) }, as: UTF8.self)
    }

    private func tokenize(_ text: String) -> [llama_token] {
        let utf8 = Array(text.utf8CString)
        var toks = [llama_token](repeating: 0, count: utf8.count + 16)
        var n = llama_tokenize(vocab, text, Int32(utf8.count - 1), &toks, Int32(toks.count), true, true)
        if n < 0 { toks = [llama_token](repeating: 0, count: Int(-n)); n = llama_tokenize(vocab, text, Int32(utf8.count - 1), &toks, Int32(toks.count), true, true) }
        return Array(toks.prefix(Int(max(n, 0))))
    }

    private func piece(_ t: llama_token) -> [UInt8] {
        var buf = [CChar](repeating: 0, count: 256)
        let n = llama_token_to_piece(vocab, t, &buf, Int32(buf.count), 0, false)
        return n > 0 ? buf.prefix(Int(n)).map { UInt8(bitPattern: $0) } : []
    }

    /// Full-prompt generation (stateless per turn: clears KV cache, then decodes the whole templated chat).
    func generate(prompt: String, maxTokens: Int, batch: Int,
                  onToken: @Sendable (String, GenStats) -> Void) throws -> GenStats {
        cancelled = false
        reset()
        var stats = GenStats()
        var tokens = tokenize(prompt)
        if tokens.count >= Int(nCtx) - 8 { tokens = Array(tokens.suffix(Int(nCtx) / 2)) }
        stats.promptTokens = tokens.count

        // Prompt processing in chunks.
        let t0 = Date()
        var i = 0
        while i < tokens.count {
            let end = min(i + batch, tokens.count)
            var chunk = Array(tokens[i..<end])
            let rc = chunk.withUnsafeMutableBufferPointer { llama_decode(ctx, llama_batch_get_one($0.baseAddress, Int32($0.count))) }
            if rc != 0 { throw NSError(domain: "llama", code: 3, userInfo: [NSLocalizedDescriptionKey: "decode failed (\(rc))"]) }
            i = end
        }
        nPast = Int32(tokens.count)
        stats.promptTPS = Double(tokens.count) / max(Date().timeIntervalSince(t0), 1e-6)
        onToken("", stats)

        // Generation.
        let t1 = Date()
        var pending: [UInt8] = []
        while stats.genTokens < maxTokens && !cancelled && nPast < nCtx {
            var tok = llama_sampler_sample(sampler, ctx, -1)
            if llama_vocab_is_eog(vocab, tok) { break }
            llama_sampler_accept(sampler, tok)
            pending += piece(tok)
            stats.genTokens += 1
            stats.genTPS = Double(stats.genTokens) / max(Date().timeIntervalSince(t1), 1e-6)
            if let s = String(validatingUTF8: pending.map { CChar(bitPattern: $0) } + [0]) { onToken(s, stats); pending.removeAll() }
            let rc = llama_decode(ctx, llama_batch_get_one(&tok, 1))
            if rc != 0 { break }
            nPast += 1
        }
        return stats
    }
}

@MainActor
final class LlamaEngine: ObservableObject {
    @Published var loadedName: String?
    @Published var isLoading = false
    @Published var isGenerating = false
    @Published var messages: [ChatMessage] = []
    @Published var stats = GenStats()
    @Published var error: String?
    @Published var maxTokens = 512
    @Published var contextSize = 4096
    private var llm: LlamaContext?

    /// Tuning: when JIT is available (debugger attached), use bigger batches / more threads.
    /// llama.cpp itself is AOT-compiled, so JIT mainly unlocks the debugger-relaxed memory
    /// policy (RWX pages); we treat it as a "performance mode" switch and fall back safely.
    private func tuning() -> (threads: Int32, batch: Int, gpu: Int32) {
        let cores = ProcessInfo.processInfo.activeProcessorCount
        if JITStatus.shared.available { return (Int32(max(2, cores - 1)), 512, 99) }
        return (Int32(max(2, min(4, cores - 2))), 256, 99)
    }

    func load(_ url: URL) async {
        isLoading = true; error = nil
        JITStatus.shared.refresh()
        let t = tuning()
        let ctxSize = Int32(contextSize)
        do {
            llm = nil
            llm = try await Task.detached { try LlamaContext(path: url.path, nCtx: ctxSize, gpuLayers: t.gpu, threads: t.threads) }.value
            loadedName = url.lastPathComponent; messages = []
        } catch { self.error = error.localizedDescription }
        isLoading = false
    }

    func send(_ text: String) async {
        guard let llm, !isGenerating else { return }
        messages.append(.init(role: "user", text: text))
        let history = messages
        messages.append(.init(role: "assistant", text: ""))
        isGenerating = true
        let batch = tuning().batch, maxT = maxTokens
        do {
            let prompt = await llm.formatPrompt(history)
            let final = try await llm.generate(prompt: prompt, maxTokens: maxT, batch: batch) { piece, s in
                Task { @MainActor in
                    if !piece.isEmpty, let last = self.messages.indices.last { self.messages[last].text += piece }
                    self.stats = s
                }
            }
            stats = final
        } catch { self.error = error.localizedDescription }
        isGenerating = false
    }

    func stop() { Task { await llm?.cancel() } }
    func clear() { messages = []; stats = GenStats() }
}
