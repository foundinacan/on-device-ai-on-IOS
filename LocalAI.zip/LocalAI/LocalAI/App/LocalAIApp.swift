import SwiftUI

@main
struct LocalAIApp: App {
    @StateObject private var jit = JITStatus.shared
    @StateObject private var downloads = DownloadManager()
    @StateObject private var engine = LlamaEngine()

    var body: some Scene {
        WindowGroup {
            TabView {
                ModelBrowserView().tabItem { Label("Hub", systemImage: "magnifyingglass") }
                LocalModelsView().tabItem { Label("Models", systemImage: "externaldrive") }
                ChatView().tabItem { Label("Chat", systemImage: "bubble.left.and.bubble.right") }
                SettingsView().tabItem { Label("Settings", systemImage: "gear") }
            }
            .environmentObject(jit)
            .environmentObject(downloads)
            .environmentObject(engine)
            .onAppear { jit.refresh() }
        }
    }
}
